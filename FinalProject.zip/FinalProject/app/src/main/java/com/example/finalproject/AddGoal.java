package com.example.finalproject;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Add goal java code
 *
 * This class contains all methods to add a user goal, including preference saving.
 **/

public class AddGoal extends AppCompatActivity {


    private EditText weightText;

    private Button confirm;

    private Button cancel;

    private Switch SMS;

    private int goalTemp;

    private String weightCheck;

    private String name;

    private boolean emptyCheck;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal);

        weightText = findViewById(R.id.goalWeight);
        cancel = findViewById(R.id.cancelButton);
        confirm = findViewById(R.id.saveButton);
        SMS = findViewById(R.id.smsSwitch);

        Intent intent = getIntent();
        name = intent.getStringExtra("name");

        //setting up shared preferences
        SharedPreferences sharedPreferences= getSharedPreferences("save"+name,MODE_PRIVATE);
        SMS.setChecked(sharedPreferences.getBoolean("value",false));
        SharedPreferences.Editor editor = getSharedPreferences("save"+name, MODE_PRIVATE).edit();


        confirm.setOnClickListener(view -> addGoal());

        cancel.setOnClickListener(view ->{

            Intent add = new Intent();
            setResult(0, add);
            this.finish();

        });


        SMS.setOnClickListener(new View.OnClickListener() {
            /**
             * Method to save switch state and preferences for SMS text notifications with user shared preferences
             **/
            @Override
            public void onClick(View view) {
                if (SMS.isChecked()) {
                    editor.putBoolean("value", true);
                    editor.apply();
                    Toast.makeText(getApplicationContext(),"Text notifications enabled", Toast.LENGTH_LONG).show();
                } else {
                    editor.putBoolean("value", false);
                    editor.apply();
                    Toast.makeText(getApplicationContext(),"Text notifications disabled", Toast.LENGTH_LONG).show();
                }
            }
        });

    }

    /**
     * Method to add goal
     **/
    private void addGoal(){
        String message = checkEmpty();

        //if text is present goal is added to shared preferences for use
        if(!emptyCheck){
            goalTemp = Integer.parseInt(weightText.getText().toString());

            SharedPreferences.Editor editor = getSharedPreferences("save"+name, MODE_PRIVATE).edit();
            editor.putInt("goal",goalTemp);
            editor.apply();

            Toast.makeText(this, "Goal added", Toast.LENGTH_LONG).show();
            //closing activity
            Intent goalAdd = new Intent();
            setResult(RESULT_OK, goalAdd);
            this.finish();

        }else{
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        }

    }

    /**
     * Method to check if edit text is empty
     * @returns string message indicating text is empty.
     **/
    private String checkEmpty() {
        String message = "";
        weightCheck = weightText.getText().toString();

        if (weightCheck.isEmpty()) {
            weightText.requestFocus();
            emptyCheck = true;
            message = "Weight entry is Empty";
        } else {
            emptyCheck = false;
        }
        return message;
    }
}
