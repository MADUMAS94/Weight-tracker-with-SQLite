package com.example.finalproject;

/**
 * Weight java code
 *
 * This class contains all constructors, getters and setters for the weight database
 *
 **/

public class Weight {

    private int id = -1;
    private String nameString;
    private int weight;
    private String date;


    public Weight(int i, int weight, String date,  String nameString) {
        super();
        this.id = i;
        this.weight = weight;
        this.date = date;
        this.nameString = nameString;
    }

    /**
     * Constructor for weight
     * @param - int weight
     * @param - string date
     * @param - string nameString
     **/
    public Weight( int weight, String date,  String nameString) {
        this.weight = weight;
        this.date = date;
        this.nameString = nameString;

    }

    public Weight(Weight weight, int updatedWeight, String date){
        this(weight.getId(),updatedWeight,date,weight.getName());
    }



    /**
     * Getter for id
     **/

    public int getId() {

        return id;
    }

    /**
     * getter for name
     **/
    public String getName() {

        return nameString;
    }

    /**
     * getter for weight
     **/
    public int getWeight() {

        return weight;
    }


    /**
     * getter for date
     **/
    public String getDate() {

        return date;
    }

}

