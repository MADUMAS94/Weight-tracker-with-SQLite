package com.example.finalproject;


import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

/** Main activity java
 *
 * Houses all functions for the main screen
 * Executes after successful login
 *
 **/


public class MainActivity extends AppCompatActivity {

    private ListView weightsListView;

    private ImageButton addWeight;

    private ImageButton addGoal;

    private ImageButton logOut;

    private TextView goalText;

    private WeightSQLiteHandler handler;

    private String name;

    private int count;

    private int goalInt;

    private int countInt;

    private WeightsList weightsList;

    private ArrayList<Weight> weights;
    private final static int ADD_GOAL = 2;

    private final static int ADD_WEIGHT = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //linking to activity_main.xml as display
        setContentView(R.layout.activity_main);
        //loading weight handler for CRUD functions
        handler = new WeightSQLiteHandler(this);

        addWeight = findViewById(R.id.addWeight);
        addGoal = findViewById(R.id.addGoal);
        logOut = findViewById(R.id.logOut);
        weightsListView = findViewById(R.id.recyclerView);
        goalText = findViewById(R.id.goalWeightText);

        //pulling user name from login activity
        Intent intent = getIntent();
        name = intent.getStringExtra("name");


        //retrieving all weights
        weights = (ArrayList<Weight>) handler.getAllWeights(name);

        //retrieving number of items in database
        count = handler.getWeightCount();

        //retrieving last goal and setting it to text
        SharedPreferences sharedPreferences= getSharedPreferences("save"+name,MODE_PRIVATE);
        goalInt = sharedPreferences.getInt("goal", 0);
        goalText.setText(""+goalInt);

        //if database is not null - populate weightsList
        //else - display toast message
        if (count > 0) {
            weightsList = new WeightsList(this, weights, handler, name);
            weightsListView.setAdapter(weightsList);

        } else {
            Toast.makeText(this, "No records", Toast.LENGTH_LONG).show();
        }

        //add weight and goal listeners, with returned result for updating screen.
        addWeight.setOnClickListener(view -> {
            Intent add = new Intent(MainActivity.this, AddWeight.class);
            //sending name string from login
            add.putExtra("name", name);
            startActivityForResult(add,ADD_WEIGHT);
        });
        addGoal.setOnClickListener(view ->{
            Intent goal = new Intent(MainActivity.this, AddGoal.class);
            goal.putExtra("name", name);
            startActivityForResult(goal,ADD_GOAL);
        });
        logOut.setOnClickListener((view ->{
            Intent out = new Intent(MainActivity.this, LoginActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(out);
        }));

    }

        @Override
        public void onActivityResult(int requestCode,int resultCode, Intent data) {
            super.onActivityResult(requestCode, resultCode, data);
            if (requestCode == ADD_WEIGHT) {
                if (resultCode == RESULT_OK) {

                    //calling on users shared preferences to check if goal has been met
                    SharedPreferences sharedPreferences= getSharedPreferences("save"+name,MODE_PRIVATE);
                    goalInt = sharedPreferences.getInt("goal", 0);
                    countInt = sharedPreferences.getInt("weight", 0);;

                    goalText.setText(""+goalInt);
                    //sending toast notification if goal is met or exceeded.
                    if(goalInt >= countInt){
                        Toast.makeText(this, "YOU HAVE MET YOUR WEIGHT GOAL!", Toast.LENGTH_SHORT).show();
                    }
                    //repopulating screen with new entry
                    if(weightsList == null)	{
                        weightsList = new WeightsList(this, weights, handler, name);
                        weightsListView.setAdapter(weightsList);
                    }

                    weightsList.weights = (ArrayList<Weight>) handler.getAllWeights(name);
                    ((BaseAdapter)weightsListView.getAdapter()).notifyDataSetChanged();
                } else {
                    Toast.makeText(this, "Action Canceled", Toast.LENGTH_SHORT).show();
                }
            }
            if(requestCode == ADD_GOAL){
                if(resultCode == RESULT_OK){

                    //calling on users shared preferences to check if goal has been met
                    SharedPreferences sharedPreferences= getSharedPreferences("save"+name,MODE_PRIVATE);
                    goalInt = sharedPreferences.getInt("goal", 0);
                    countInt = sharedPreferences.getInt("weight", 0);

                    goalText.setText(""+goalInt);

                    if(goalInt >= countInt){
                        Toast.makeText(this, "YOU HAVE MET YOUR WEIGHT GOAL!", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(this, "Action Canceled", Toast.LENGTH_SHORT).show();
                    }

            }
        }
    }
