package com.example.finalproject;

/**
 * Users java code
 *
 * Contains class constructors and getters/setters for user database variables
 *
 **/

public class User {

        private String userName;
        private String userPass;

        //constructor
        public User(String name, String password) {
            this.userName = name;
            this.userPass = password;
        }
        /**
        * Getter for userName
        **/
        public String getUserName() {
            return userName;
        }

        /**
        * Getter for userPass
         **/
        public String getUserPass() {
            return userPass;
        }

}
