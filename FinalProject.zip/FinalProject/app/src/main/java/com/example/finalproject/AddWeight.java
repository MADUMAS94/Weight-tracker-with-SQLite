package com.example.finalproject;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Add weight java code
 *
 * This class contains all code to get and store weight data
 **/

public class AddWeight extends AppCompatActivity{

    private String dateTemp;
    private String weightCheck;

    private String name;

    private EditText dateText;

    private EditText weightText;

    private Button confirmAdd;

    private Button cancelAdd;

    private boolean emptyCheck;

    private boolean dupCheck;

    private WeightSQLiteHandler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        confirmAdd = findViewById(R.id.saveWeightButton);
        cancelAdd = findViewById(R.id.cancelWeightButton);
        dateText = findViewById(R.id.dateEditText);
        weightText = findViewById(R.id.weightEditText);

        //pulling name string from main
        Intent intent = getIntent();
        name = intent.getStringExtra("name");

        handler = new WeightSQLiteHandler(this);

        confirmAdd.setOnClickListener(view -> addNewWeight());

        cancelAdd.setOnClickListener(view ->{

            Intent add = new Intent();
            setResult(0, add);
            this.finish();

        });

    }
    /**
     * Method to add new weight into database
     **/
    private void addNewWeight(){
        String message = checkEmpty();

        String date = dateTemp;

        //checking if date already exists
        dupCheck = handler.checkDuplicate(dateTemp, name);

        //adding weight if not duplicate and text is not empty
        if (!emptyCheck && !dupCheck) {

            int weightVar = Integer.parseInt(weightText.getText().toString());
            Weight weight = new Weight(weightVar, date, name);
            handler.createWeight(weight);

            //adding weight to shared preferences for user - this is for goal reached notification in MainActivity.java
            SharedPreferences.Editor editor = getSharedPreferences("save"+name, MODE_PRIVATE).edit();
            editor.putInt("weight",weightVar);
            editor.apply();

            Toast.makeText(this,"Record Added", Toast.LENGTH_LONG).show();

            //finishing intent and moving back to main screen
            Intent add = new Intent();
            setResult(RESULT_OK, add);
            this.finish();
        }
        //toast messages for if duplicate date or blank text is detected
        if (dupCheck) {
            Toast.makeText(this, "Duplicate Date", Toast.LENGTH_LONG).show();
        }
        if(emptyCheck) {
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Method to check if edit texts are empty
     * @returns - string message indicating which text is empty
     **/
    private String checkEmpty() {
        String message = "";
        weightCheck = weightText.getText().toString();
        dateTemp = dateText.getText().toString();

        if (weightCheck.isEmpty()) {
            weightText.requestFocus();
            emptyCheck = true;
            message = "Weight entry is Empty";
        } else if (dateTemp.isEmpty()){
            dateText.requestFocus();
            emptyCheck = true;
            message = "Date entry is Empty";
        } else {
            emptyCheck = false;
        }
        return message;
    }


}
