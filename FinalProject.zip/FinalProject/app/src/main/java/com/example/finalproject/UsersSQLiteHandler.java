package com.example.finalproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;


/** Users SQlite handler
 *
 * Creates the database and handles all the crud functions for user logins
 *
 **/

public class UsersSQLiteHandler extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;

    private static final String DATABASE_NAME = "UsersDataTest.DB";
    public static final String TABLE_NAME = "UsersTable";

    public static final String COLUMN_0_ID = "id";
    public static final String COLUMN_1_NAME = "username";

    public static final String COLUMN_2_PASSWORD = "password";


    private static final String CREATE_USERS_TABLE = " CREATE TABLE IF NOT EXISTS " +
            TABLE_NAME + " (" +
            COLUMN_0_ID + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
            COLUMN_1_NAME + " VARCHAR, " +
            COLUMN_2_PASSWORD + " VARCHAR" + ");";

    public UsersSQLiteHandler(Context context) {

        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase database) {

        database.execSQL(CREATE_USERS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    //CRUD FUNCTIONS

    /**
     * Adds new user to database
     * @param - class User - contains String userName and String userPass
     **/
    public void createUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_1_NAME, user.getUserName());
        values.put(COLUMN_2_PASSWORD, user.getUserPass());

        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    /**
     * Checks if user exists
     * @param name - String name - users entered name from login nameEditText
     * @return userFound - String userFound - sends 'yes' or 'no' if user is found
     **/
    public String findUser(String name) {

        String userFound = "No";

        SQLiteDatabase db = this.getWritableDatabase();

        //searching database with name as cursor
        Cursor cursor = db.query(UsersSQLiteHandler.TABLE_NAME, null, " " + UsersSQLiteHandler.COLUMN_1_NAME + "=?", new String[]{name}, null, null, null);

        while (cursor.moveToNext()) {
            //if entry matches cursor setting string to yes.
            if (cursor.isFirst()) {

                cursor.moveToFirst();

                userFound = "Yes";

                cursor.close();
            }
        }
        return userFound;
    }

    /**
     * Method to get users password
     * @param name - String name - users entered name from login nameEditText
     * @return tempPassword - String temPassword - returns password that matches name from database
     **/
    public String getLogin(String name){
        SQLiteDatabase db = this.getWritableDatabase();

        String tempPassword = "none";

        //searching with name as cursor
        Cursor cursor = db.query(UsersSQLiteHandler.TABLE_NAME,null, " "+ UsersSQLiteHandler.COLUMN_1_NAME + "=?", new String[]{name},null,null,null);

        while (cursor.moveToNext()){
            if(cursor.isFirst()){
                cursor.moveToFirst();

                //storing password and name with temp variables
                tempPassword = cursor.getString(cursor.getColumnIndexOrThrow(UsersSQLiteHandler.COLUMN_2_PASSWORD));

                cursor.close();
            }
        }
        return tempPassword;
    }
}

