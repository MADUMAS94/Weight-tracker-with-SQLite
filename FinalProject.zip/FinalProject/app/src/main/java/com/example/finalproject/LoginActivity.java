package com.example.finalproject;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Login activity java code
 * Houses all functions for user login and registration
 * This is the default boot activity
 **/

public class LoginActivity extends AppCompatActivity {

    private Activity activity;

    private Button LoginButton;

    private Button RegisterButton;

    private EditText usernameText;

    private EditText passwordText;

    private String nameTemp;

    private String passwordTemp;

    private Boolean emptyCheck;

    private SQLiteDatabase db;

    private UsersSQLiteHandler handler;

    private String tempPassword = "NO";

    private String userFound = "NO";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        activity = this;
        //calling on User database handler for CRUD functions
        handler = new UsersSQLiteHandler(this);
        //button and text registrations
        LoginButton = findViewById(R.id.loginButton);
        RegisterButton = findViewById(R.id.registerButton);

        usernameText = findViewById(R.id.editTextUsername);
        passwordText = findViewById(R.id.editTextPassword);

        passwordTemp = passwordText.getText().toString();
        nameTemp = usernameText.getText().toString();

        LoginButton.setOnClickListener(view -> {

            Login();

        });

        RegisterButton.setOnClickListener(view ->{

            Register();
        });

    }

    /**
     * Method to validate login
     **/
    private void Login(){

        //calling method to check if text is empty
        String message = emptyText();

        if(emptyCheck != true){

            tempPassword = handler.getLogin(nameTemp);

            //calling final result to bundle and finish login
            finalResult();

        } else {
            Toast.makeText(LoginActivity.this, message, Toast.LENGTH_LONG).show();
        }

    }

    /**
     * Method to register a new user
     **/
    private void Register(){

        //checking for empty text
        String message = emptyText();

        if(emptyCheck != true){

            //checking for existing user
            checkUserExists();
            //emptying text after
            emptyTextAfter();
        } else {
            Toast.makeText(LoginActivity.this, message, Toast.LENGTH_LONG).show();
        }
    }



    /**
     * Method to check if user already exists
     **/
    private void checkUserExists() {

        userFound = handler.findUser(nameTemp);

        //sending toast notification if user is found
        if(userFound.equalsIgnoreCase("Yes")){
            Toast.makeText(LoginActivity.this,"User already exists",Toast.LENGTH_LONG).show();
        }
        else {
            newUser();
        }

    }


    /**
     * Method to create a new user
     **/
    private void newUser(){
        String username = usernameText.getText().toString().trim();
        String password = passwordText.getText().toString().trim();

        User user = new User(username, password);
        handler.createUser(user);

        Toast.makeText(LoginActivity.this,"User created. Please login.",Toast.LENGTH_LONG).show();
    }



    /**
     * Method to check for empty edit text
     * @returns String message indicating which text is empty
     **/
    private String emptyText(){

        String message = " ";

        nameTemp = usernameText.getText().toString().trim();
        passwordTemp = passwordText.getText().toString().trim();

        if (nameTemp.isEmpty()){
            usernameText.requestFocus();
            emptyCheck =  true;
            message = "Please enter username";
        } else if (passwordTemp.isEmpty()){
            passwordText.getText().toString().trim();
            emptyCheck = true;
            message = "Please enter password";
        } else {
            emptyCheck = false;
        }
        return message;

    }

    /**
     * Method to validate then bundle login credentials - then moves to new activity
     **/
    private void finalResult(){

        if (tempPassword.equalsIgnoreCase(passwordTemp)){
            Toast.makeText(LoginActivity.this,"Login Successful",Toast.LENGTH_SHORT).show();

            String user = usernameText.getText().toString().trim();

            Bundle bundle = new Bundle();
            bundle.putString("user_name", nameTemp);

            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            intent.putExtras(bundle);
            intent.putExtra("name", user);
            startActivity(intent);

            emptyTextAfter();
        }else{

            Toast.makeText(LoginActivity.this,"Invalid login credentials",Toast.LENGTH_LONG).show();
        }

        tempPassword = "No";

    }

    /**
     * Method to empty text after login or registration
     **/
    private void emptyTextAfter(){
        usernameText.getText().clear();
        passwordText.getText().clear();
    }
}
