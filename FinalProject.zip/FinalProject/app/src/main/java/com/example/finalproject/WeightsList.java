package com.example.finalproject;


import android.app.Activity;

import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;


import java.util.ArrayList;

/**
 * Weights list java code
 *
 * This class contains all code to populate the main screen with the information from the database.
 * This class also contains the modify and delete options for the users records.
 *
 **/

public class WeightsList extends BaseAdapter {

    private final Activity context;

    private PopupWindow modifyWeight;

    private String name;

    ArrayList<Weight> weights;
    private WeightSQLiteHandler handler;


    /**
     * WeightLists adapter constructor
     **/
    public WeightsList(Activity context, ArrayList<Weight> weight, WeightSQLiteHandler handler, String name) {
        this.context = context;
        this.weights = weight;
        this.handler = handler;
        this.name = name;
    }

    /**
     * ViewHolder to set textview and buttons from the item_row_template.xml
     **/
    private static class ViewHolder {
        TextView textViewDate;

        TextView textViewWeight;

        ImageButton editWeight;

        ImageButton deleteWeight;
    }

    /**
     * GetView class that utilizes layoutInflater to populate items.
     **/
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        LayoutInflater inflater = context.getLayoutInflater();
        ViewHolder vh;


        if (convertView == null) {
            vh = new ViewHolder();
            row = inflater.inflate(R.layout.item_row_template, null, true);

            vh.textViewDate = row.findViewById(R.id.textViewDate);
            vh.textViewWeight = row.findViewById(R.id.textViewWeight);
            vh.editWeight = row.findViewById(R.id.editWeight);
            vh.deleteWeight = row.findViewById(R.id.deleteWeight);

            row.setTag(vh);
        } else {
            vh = (ViewHolder) convertView.getTag();
        }

        //setters for textviews.
        vh.textViewDate.setText("Date: " + weights.get(position).getDate());
        vh.textViewWeight.setText("Weight: " + weights.get(position).getWeight());

        final int positionPopUp = position;

        //listeners for buttons
        vh.editWeight.setOnClickListener(view -> editWeightScreen(positionPopUp));


        vh.deleteWeight.setOnClickListener(view ->{
            handler.deleteWeight(weights.get(positionPopUp));
            weights = (ArrayList<Weight>) handler.getAllWeights(name);
            this.notifyDataSetChanged();

            Toast.makeText(context, "Record Deleted", Toast.LENGTH_SHORT).show();
        });

        return  row;
    }

    public Object getItem(int position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }

    public int getCount() {
        return weights.size();
    }

    /**
     * Method to edit existing entries
     **/
    private void editWeightScreen(final int positionPopup){
        LayoutInflater inflater = context.getLayoutInflater();
        View layout = inflater.inflate(R.layout.activity_modify, context.findViewById(R.id.modifyWeight));

        //pop window location and size
        modifyWeight = new PopupWindow(layout, 800, 1000, true);
        modifyWeight.showAtLocation(layout, Gravity.CENTER, 0, 0);

        //setting text views in pop window
        final TextView dateText = layout.findViewById(R.id.dateText);
        final EditText weightText = layout.findViewById(R.id.weightEditText);

        dateText.setText("Date: " + weights.get(positionPopup).getDate());
        weightText.setText("" + weights.get(positionPopup).getWeight());

        Button confirm = layout.findViewById(R.id.saveButton);
        Button cancel = layout.findViewById(R.id.cancelButton);



        confirm.setOnClickListener(view ->{

            //setting date as string and weight as int
            String date = weights.get(positionPopup).getDate();
            int weightVar = Integer.parseInt(weightText.getText().toString());

            Weight weight = weights.get(positionPopup);

            Weight updated = new Weight(weight,weightVar,date);

            //calling SQL manager for weights and creating new list
            handler.updateWeight(updated);
            weights = (ArrayList<Weight>) handler.getAllWeights(name);
            this.notifyDataSetChanged();

            Toast.makeText(context, "Record Updated", Toast.LENGTH_SHORT).show();

            //dismissing pop window
            modifyWeight.dismiss();

        });

        cancel.setOnClickListener(view -> {

            Toast.makeText(context, "Weight change Canceled", Toast.LENGTH_SHORT).show();
            modifyWeight.dismiss();
        });

    }

}