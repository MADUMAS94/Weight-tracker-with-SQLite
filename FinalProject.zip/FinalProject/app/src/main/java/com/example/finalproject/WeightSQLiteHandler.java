package com.example.finalproject;

import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;


/** Weights SQlite handler
 *
 * Creates the database and handles all the crud functions for user weights entries
 *
 **/

public class WeightSQLiteHandler extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;

    private static final String DATABASE_NAME = "WeightData.DB";
    private static final String TABLE_NAME = "WeightTable";

    private static final String COLUMN_0_ID = "id";
    private static final String COLUMN_1_DATE = "date";
    private static final String COLUMN_2_WEIGHT = "weight";

    private static final String COLUMN_3_NAME = "name";

    private int count = 0;


    private static final String CREATE_WEIGHT_TABLE = "CREATE TABLE IF NOT EXISTS " +
            TABLE_NAME + " (" +
            COLUMN_0_ID + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
            COLUMN_1_DATE + " VARCHAR, " +
            COLUMN_2_WEIGHT + " VAR," +
            COLUMN_3_NAME + " VARCHAR" + ");";

    public WeightSQLiteHandler(Context context) {

        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase database) {

        database.execSQL(CREATE_WEIGHT_TABLE);
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    //CRUD FUNCTIONS

    /**
     * Adds new weight to database
     * @param weight- weight constructor (string name, int wieght, string date)
     * @return newId- long newId for confirmation of insertion
     **/
    public long createWeight(Weight weight) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_1_DATE, weight.getDate());
        values.put(COLUMN_2_WEIGHT, weight.getWeight());
        values.put(COLUMN_3_NAME, weight.getName());

        long newId = db.insert(TABLE_NAME, null, values);
        db.close();

        return newId;

    }


    /**
     * Updates existing weight entry
     * @param weight - weight constructor (string name, int weight, string date)
     * @return db.update - updated database entry
     **/
    public int updateWeight(Weight weight) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_1_DATE, weight.getDate());
        values.put(COLUMN_2_WEIGHT, weight.getWeight());
        values.put(COLUMN_3_NAME, weight.getName());

        return db.update(TABLE_NAME, values, COLUMN_0_ID + " = ?", new String[]{String.valueOf(weight.getId())});
    }

    /**
     * Deletes weight entry
     * @param weight - weight constructor (string name, int weight, string date)
     * @return result - int result 1 for confirmation of deletion
     **/
    public boolean deleteWeight(Weight weight) {
        SQLiteDatabase db = this.getWritableDatabase();

        int result = db.delete(TABLE_NAME, COLUMN_0_ID + " = ?", new String[]{String.valueOf(weight.getId())});
        db.close();
        return result == 1;
    }


    /**
     * Retrieves list of all weights
     * @param name - name string for user
     * @return list<Weight> weightList - list of all weights matching users login name
     **/
    public List<Weight> getAllWeights(String name) {
        List<Weight> weightList = new ArrayList<>();

        String selectQuery = "SELECT * FROM " + TABLE_NAME;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        //parsing through database, then adding to list if name matches.
        if (cursor.moveToFirst()) {
            do {
                String check = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                if (check.equalsIgnoreCase(name)) {

                    int id = cursor.getInt(0);
                    String date = cursor.getString(1);
                    int weightVar = cursor.getInt(2);
                    String nameString = cursor.getString(3);

                    Weight weight = new Weight(id,weightVar, date, nameString);

                    weightList.add(weight);
                }
            } while (cursor.moveToNext());
        }

        cursor.close();

        return weightList;
    }

    /**
     * Returns total number of items inside database
     * @return weight total - returns total number of items in the database
     **/
    public int getWeightCount() {
        String countQuery = "SELECT * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        int weightTotal = cursor.getCount();
        cursor.close();

        return weightTotal;
    }

    /**
     * Checks if new entry is duplicate
     * @param date - entries date string
     * @param name - users name string
     * @return isDup - Boolean returning true if date already exists for user
     **/
    public boolean checkDuplicate(String date, String name) {

        boolean isDup = false;
        String selectQuery = "SELECT * FROM " + TABLE_NAME;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                String checkN = cursor.getString(cursor.getColumnIndexOrThrow("name"));
                String checkD = cursor.getString(cursor.getColumnIndexOrThrow("date"));
                if (checkN.equalsIgnoreCase(name) && checkD.equalsIgnoreCase(date)) {
                        isDup = true;
                }
            } while (cursor.moveToNext());
        }

        cursor.close();

        return isDup;

    }

}
